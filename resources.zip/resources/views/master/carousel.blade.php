<div id="myCarousel" class="carousel slide">
               <div class="carousel-inner">
                  <div class="item active">
                     <img src="{{asset('rooms/1.jpg')}}">
                  </div>
                    <div class="item">
                   <img src="{{asset('rooms/2.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/3.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/4.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/5.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/6.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/7.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/8.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/9.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/10.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/11.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/12.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/13.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/14.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/15.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/16.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/17.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/18.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/19.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/20.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/21.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/22.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/23.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/24.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/25.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/26.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/27.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/28.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/29.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/30.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/31.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/32.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/33.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/34.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/35.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/36.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/37.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/38.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/39.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/40.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/41.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/42.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/43.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/44.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/45.jpg')}}">
                </div>
                <div class="item">
                   <img src="{{asset('rooms/46.jpg')}}">
                </div>
             </div>
             <!-- Carousel nav -->
             <a class="carousel-control left" href="#myCarousel"
                data-slide="prev">&lsaquo;</a>
             <a class="carousel-control right" href="#myCarousel"
                data-slide="next">&rsaquo;</a>
            </div>