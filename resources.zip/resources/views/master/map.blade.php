<div class="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3858.795301845491!2d121.03681831457364!3d14.724161989723878!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b0ff2c71d3d5%3A0xfa7ee1d7272c67d2!2sMchotel!5e0!3m2!1sen!2sph!4v1518429975681" width="700" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>