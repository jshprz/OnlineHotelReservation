<style>
h1{
    font-family:Segoe UI Light;
}
</style>


<div id="footer" class="text-center footer-color">
<div class="container">
<div class="row">
<div class="col-md-4">
@include('master/map')
</div>
<div class="col-md-8">
<div class="mytext">
 <h1>2017 @ Mchotel Data</h1>
</div>
</div>
</div>
</div>