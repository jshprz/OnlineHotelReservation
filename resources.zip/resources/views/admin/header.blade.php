<ul>
<h3>
  <li><a href="recentlogin.php">RECENT LOGIN</a></li>
  <li><a href="#recenttransac">VIEW RECENT TRANSACTION</a></li>
  <li><a href="#contact">ADMIN LOGS</a></li>
  <li><a href="#user">USER LOGS</a></li>
  <li><a href="#clear">CLEAR ALL DATA</a></li>
 <p>HELLO {{strtoupper(Auth::user()->firstname)}} {{strtoupper(Auth::user()->lastname)}}</p>
</ul>
</h3>
<div class="header">
MCHOTEL ADMIN

</div>