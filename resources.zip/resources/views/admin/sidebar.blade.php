<div class="sidenav">
	<ul>
  <a href="{{route('admin')}}">DASHBOARD</a>
  <a href="{{route('users')}}">USERS</a>
  <a href="{{route('rooms')}}">ROOMS</a>
  <a href="{{route('image')}}">IMAGES</a>
  <a href="{{route('customer')}}">CUSTOMER HISTORY</a>
  <a href="{{route('setting')}}">SETTINGS</a>




</ul>
</div>
