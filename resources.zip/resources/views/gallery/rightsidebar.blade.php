<div class="card-side card-container">
           asdas
    </div><!-- /container -->