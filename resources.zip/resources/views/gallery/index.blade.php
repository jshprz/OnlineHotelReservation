@extends('master/index')
 
@section('content')
    @include('gallery/rightsidebar')   

    @endsection